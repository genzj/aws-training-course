from __future__ import print_function
import boto3
import os
import sys
import uuid
import urllib.parse
from PIL import Image
import PIL.Image
import logging

L = logging.getLogger(__name__)
L.setLevel(logging.DEBUG)

s3_client = boto3.client('s3')

def resize_image(image_path, resized_path):
    with Image.open(image_path) as image:
        image.thumbnail(tuple(x / 2 for x in image.size))
        image.save(resized_path)

def handler(event, context):
    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        key = urllib.parse.unquote_plus(record['s3']['object']['key'])

        download_path = '/tmp/{}{}'.format(uuid.uuid4(), key)
        L.info('ready to download %s/%s to %s', bucket, key, download_path)

        upload_path = '/tmp/resized-{}'.format(key)
        s3_client.download_file(bucket, key, download_path)
        resize_image(download_path, upload_path)
        target = '{}-resized'.format(bucket)
        s3_client.upload_file(upload_path, target, key)
        L.info('going to upload %s to %s', upload_path, target)
